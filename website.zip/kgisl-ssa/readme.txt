Thanks for downloading this theme!

Theme Name: Medicio
Theme URL: https://bootstrapmade.com/medicio-free-bootstrap-theme/
Author: BootstrapMade
Author URL: https://bootstrapmade.com