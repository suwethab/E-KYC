<?php
include('config.php');
$uploadOk = 0;
if(isset($_POST['submit'])) {
	
	$uploadOk = 1;
	
	$namea = $_POST['empid'];
	$nameb = $_POST['empname'];
	$namec = $_POST['designation'];
	$named = $_POST['entercurrentscore'];
	$namee = $_POST['dept'];
	$namef = $_POST['trainingtiming'];
	$nameg = $_POST['batch'];
	$nameh = $_POST['currentbeclevel'];
	$namei = $_POST['trngreqbeclevel'];
	$namej = $_POST['upgraderequest'];
	$namek = $_POST['currentlocation'];
	


	
$query=mysql_query("INSERT INTO `certificate`(`empid`, `empname`,`designation`,`entercurrentscore`,`dept`,`trainingtiming`,`batch`,`currentbeclevel`,`trngreqbeclevel`,`upgraderequest`,`currentlocation`)
VALUE ('".$namea."','".$nameb."','".$namec."','".$named."','".$namee."','".$namef."','".$nameg."','".$nameh."','".$namei."','".$namej."','".$namek."')");


if($query)
{

	echo "
	
	
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>

<!-- Latest compiled JavaScript -->
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>

    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css' integrity='sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO' crossorigin='anonymous'>
     <script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>
	 <script>
	 window.location='certified.php;
swal('Good job!', 'You clicked the button!', 'success')

</script>";
	
	
}
else{
	$uploadOk = 0;
	die("connection error:".mysql_error());
}
}
?>


<!DOCTYPE html>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>KGiSL</title>
	
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
	<link href="css/nivo-lightbox.css" rel="stylesheet" />
	<link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
	<link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
	<!-- template skin -->
	<link id="t-colors" href="color/default.css" rel="stylesheet">
    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script>
	
	$(document).ready(function(){
    $("#score").change(function(){
	       
		   if($("#des").val()=="Jr Associate/Trainee")
	              {
				      if($("#score").val()<130)
					  
					  { 
					   $("#ans").empty();
					$("#ans").append('<option value="Yes">Yes</option>');
					  
					  }
					  else if($("#score").val()>=130)
					  {
					    $("#ans").empty();
					  $("#ans").append('<option value="No">No</option>');
					  }
				  
				  
				  }
				  
				  
				  
				  
				  
				   if($("#des").val()=="ASSOCIATE")
	              {
				      if($("#score").val()<140)
					  
					  { 
					   $("#ans").empty();
					$("#ans").append('<option value="Yes">Yes</option>');
					  
					  }
					  else if($("#score").val()>=140)
					  {
					    $("#ans").empty();
					  $("#ans").append('<option value="No">No</option>');
					  }
				  
				  
				  }
				  
				  
				  
				  
				  
				   if($("#des").val()=="Sr.ASSOCIATE")
	              {
				      if($("#score").val()<143)
					  
					  { 
					   $("#ans").empty();
					$("#ans").append('<option value="Yes">Yes</option>');
					  
					  }
					  else if($("#score").val()>=143)
					  {
					    $("#ans").empty();
					  $("#ans").append('<option value="No">No</option>');
					  }
				  
				  
				  }
				  
				  
				  if($("#des").val()=="PL")
	              {
				      if($("#score").val()<147)
					  
					  { 
					   $("#ans").empty();
					$("#ans").append('<option value="Yes">Yes</option>');
					  
					  }
					  else if($("#score").val()>=147)
					  {
					    $("#ans").empty();
					  $("#ans").append('<option value="No">No</option>');
					  }
				  
				  
				  }
				  
				  
				  if($("#des").val()=="PM")
	              {
				      if($("#score").val()<155)
					  
					  { 
					   $("#ans").empty();
					$("#ans").append('<option value="Yes">Yes</option>');
					  
					  }
					  else if($("#score").val()>=155)
					  {
					    $("#ans").empty();
					  $("#ans").append('<option value="No">No</option>');
					  }
				  
				  
				  }
				  
				  if($("#des").val()=="PGM,Directors & VP")
	              {
				      if($("#score").val()<160)
					  
					  { 
					   $("#ans").empty();
					$("#ans").append('<option value="Yes">Yes</option>');
					  
					  }
					  else if($("#score").val()>=160)
					  {
					    $("#ans").empty();
					  $("#ans").append('<option value="No">No</option>');
					  }
				  
				  
				  }
	
	
    });
});
	
	
	
	
	
	
	
	</script>

	
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">

<div id="wrapper">
	
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="top-area">
			<div class="container">
				<div class="row">
					<div class="col-sm-0 col-md-12">
					<p class="bold text-center">BEC CERTIFICATION – TRAINING REQUISITION FORM </p>
					</div>
					
				</div>
			</div>
		</div>

		
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="">
                    <img src="img/logo.png" alt="" width="150" height="40" />
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
          
			  <ul class="nav navbar-nav">
				<div class="buttonview">
				&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;
<a class="btn btn-primary" href="certified.php" role="button">BEC Upgradation Training</a>
<a class="btn btn-primary" href="noncertified.php" role="button">New BEC Certification</a>
</div>
				
			  </ul>
         
            <!-- /.navbar-collapse -->
      
        <!-- /.container -->
    </nav>
	<!-- Section: intro -->
	
    <section id="intro" class="intro">
		<div class="intro-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
					<div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
					<h2 class="h-ultra">BEC CERTIFICATION </h2>
					</div>
					<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.1s">
					<h4 class="h-light">NEXT EXAM DATE: 14th March 2019<br><br><span class="badge custom-badge red pull-left">*** Last date to submit this form is Tomorrow EOD (17/10/2018)***</span> </h4>
					</div>
						<div class="well well-trans">
						<div class="wow fadeInRight" data-wow-delay="0.1s">

						<table class="table table-bordered">
  <thead>
    <tr>
      <center><h4><b>Expected Score</b></h4></center>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Jr Associate/Trainee</td>
      <td>130</td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Associate</td>
      <td>140</td>

    </tr>
	 <tr>
      <th scope="row">3</th>
      <td>Sr.Associate</td>
      <td>143</td>

    </tr>
	 <tr>
      <th scope="row">4</th>
      <td>PL</td>
      <td>147</td>

    </tr>
	<tr>
      <th scope="row">5</th>
      <td>PM</td>
      <td>155</td>

    </tr><tr>
      <th scope="row">6</th>
      <td>PGM,Directors & VP's</td>
      <td>160</td>

    </tr>
    
  </tbody>
</table>

						</div>
						</div>


					</div>
					
					<div class="col-lg-6">
						<div class="form-wrapper">
						<div class="wow fadeInRight" data-wow-duration="2s" data-wow-delay="0.2s">
						
							<div class="panel panel-skin">
							<div class="panel-heading">
									<h3 class="panel-title"><span class="fa fa-pencil-square-o"></span>BEC CERTIFIED CANDITATE <!--<small>(It's free!)</small>--></h3>
									</div>
									<div class="panel-body">
									    
                                   
								   
								   <body>
    					                
										<form method="post"  >
										
    										
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Employee ID</label>
    													<input type="text" name="empid"  class="form-control" required data-error="Please upload your file">
                                                     
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Employee Name</label>
    													<input type="text" name="empname"  class="form-control" required data-error="Please upload your file">
                                                  
    												</div>
    											</div>


    										
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Designation</label>
														
														
														<select class="custom-select form-control"  name="designation" id="des"  required data-error="Please upload your file">
		<option selected></option>
  <option value="Jr Associate/Trainee">Jr Associate/Trainee</option>
  <option value="ASSOCIATE">ASSOCIATE</option>
  <option value="Sr.ASSOCIATE"> Sr.ASSOCIATE</option>
  
  <option value="PL">PL</option>
  <option value="PM">PM</option>
  <option value="PGM,Directors & VP">PGM,Directors & VP</option>
 
</select>
    			
                                                        <div class="validation"></div>
														
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Enter Current Scores</label>
    													<input type="text" name="entercurrentscore"  class="form-control" id="score"  required data-error="Please upload your file">
                                                        
    												</div>
    											</div>
    										
											
											
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Department</label>
    													<input type="text" name="dept"  class="form-control" required data-error="Please upload your file">
                                                  
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Training Timing</label>
    													<select class="custom-select form-control"  name="trainingtiming" required data-error="Please upload your file" >
		<option selected></option>
  <option value="09.00 am - 11.00 am">09.00 am - 11.00 am</option>
  <option value="10:00 am – 12:00 pm">10.00 am - 12.00 pm</option>
  <option value="11:00 am – 01:00 pm">11:00 am – 01:00 pm</option>
  <option value="01:00 pm – 03:00 pm">01:00 pm – 03:00 pm</option>
  <option value="03:00 pm – 05:00 pm">03:00 pm – 05:00 pm</option>
  <option value="05:00 pm – 07:00 pm">05:00 pm – 07:00 pm</option>
</select>
                                                    
    												</div>
    											</div>
    										
											
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Batch</label>
    													 <select class="custom-select form-control"  name="batch" required data-error="Please upload your file" >
  <option selected></option>
  <option value="Monday / Wednesday">Monday / Wednesday</option>
  <option value="Tuesday / Thursday">Tuesday / Thursday</option>
  <option value="Friday / Saturday">Friday / Saturday</option>
  <option value="Saturday / Sunday">Saturday / Sunday</option>
</select>
                                                  
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Current BEC Level</label>
    													 <select class="custom-select form-control"  name="currentbeclevel"required data-error="Please upload your file" >
   <option selected></option>
          <option value="B1 – Pass with Merit">B1 – Pass with Merit</option>
          <option value="B1 – Pass">B1 – Pass</option>A2
		  <option value="A2">A2</option>
</select>
                                                    
    												</div>
    											</div>
    										
											
										
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Expected BEC Level</label>
    											 <select class="custom-select form-control" input type="text"  name="trngreqbeclevel" required data-error="Please upload your file">
   <option selected></option>
          <option value="B2">B2</option>
          <option value="B1 – Pass with distinction">B1 – Pass with distinction</option>
		   <option value="B1 - Pass with merit">B1 - Pass with merit</option>
		   <option value="B1 – Pass">B1 – Pass</option>
</select>
                                                       
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Upgrade Request</label><br>
    													<select class="custom-select form-control" id="ans" name="upgraderequest" required data-error="Please upload your file">


		
</select>
                                                        
    												</div>
    											</div>
												<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Current Location</label><br>
    										 <select class="custom-select form-control" input type="text"  name="currentlocation" required data-error="Please upload your file">
   <option selected></option>
          <option value="Onsite">Onsite</option>
          <option value="Offshore">Offshore</option>
		  
</select>

		
</select>
                                                        
    												</div>
    											</div>
    										
    										
											 
      <div style="margin-center:10px">
        <button type="submit" name="submit" class="btn btn-skin btn-block btn-lg">Submit</button>
      </div>
 

    								
    									
    									
										</body>
											</form>
											
											
				
											
								</div>
								
							</div>				
						
						</div>
						</div>
					</div>					
				</div>		
			</div>
		</div>		
    </section>

	
	<!-- /Section: intro -->

	<!-- Section: boxes -->
   
           

	
				
		<div class="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-6">
					<div class="wow fadeInLeft" data-wow-delay="0.1s">
					<div class="text-left">
					<p>&copy;Copyright - KGiSL. All rights reserved.</p>
					</div>
					</div>
				</div>
				
			</div>	
		</div>
		</div>
	</footer>

</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

	<!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>
   
    <script src="contactform/contactform.js"></script>
    
</body>

</html>
<script>
	
	var saved = '<?php echo isset($uploadOk) ? $uploadOk : 1; ?>';
	
$(function(){
	if(saved == 1){
		swal(
		  'Successfully Registered!',
		  
		  
		);
		
	}
});			
	
	
	</script>