<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "becnew";
$con = mysqli_connect($hostname,$username,$password,$database);
 if(! $con ){
            die('Could not connect: ' . mysqli_error());
         }
		 else{
			 //echo "error";
		 }
?>


