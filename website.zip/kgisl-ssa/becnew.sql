-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2018 at 08:43 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `becnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `certificate`
--

CREATE TABLE `certificate` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `empid` varchar(200) NOT NULL,
  `empname` varchar(200) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `entercurrentscore` varchar(200) NOT NULL,
  `dept` varchar(200) NOT NULL,
  `trainingtiming` varchar(200) NOT NULL,
  `batch` varchar(200) NOT NULL,
  `currentbeclevel` varchar(200) NOT NULL,
  `trngreqbeclevel` varchar(200) NOT NULL,
  `upgraderequest` varchar(200) NOT NULL,
  `currentlocation` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `certificate`
--

INSERT INTO `certificate` (`id`, `status`, `created_at`, `empid`, `empname`, `designation`, `entercurrentscore`, `dept`, `trainingtiming`, `batch`, `currentbeclevel`, `trngreqbeclevel`, `upgraderequest`, `currentlocation`) VALUES
(1, 1, '2018-10-16 11:31:46', '19564', 'Rajendrakumar.A', 'ASSOCIATE', '68', 'sdf', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'B1 â€“ Pass with Merit', 'B2', 'Yes', 'Offshore'),
(2, 1, '2018-10-16 11:36:17', '10613', 'Gokila vani G', 'PL', '134', 'KEC', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(3, 1, '2018-10-16 11:36:31', '14201', 'Muthukumaran G', 'Sr.ASSOCIATE', '138', 'JIRA', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(4, 1, '2018-10-16 11:40:22', '14201', 'Muthukumaran G', 'ASSOCIATE', '138', 'JIRA', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'A2', 'B1 - Pass with merit', 'Yes', 'Offshore'),
(5, 1, '2018-10-16 11:41:27', '19351', 'Abuthahir', 'Sr.ASSOCIATE', '68', 'NSure', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(6, 1, '2018-10-16 11:44:22', '19297', 'GOVENDHAN', 'PL', '141', 'RELEASE MANAGEMENT TEAM', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass with distinction', 'Yes', 'Offshore'),
(7, 1, '2018-10-16 11:46:35', '17697', 'Anandraj', 'ASSOCIATE', '149', 'GSS/KCLAIMS (607)', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'B1 â€“ Pass', 'B1 â€“ Pass', 'No', 'Offshore'),
(8, 1, '2018-10-16 11:46:39', '16964', 'Yukthika', 'Sr.ASSOCIATE', '155', 'IAS', '05:00 pm â€“ 07:00 pm', 'Monday / Wednesday', 'B1 â€“ Pass with Merit', 'B2', 'No', 'Offshore'),
(9, 1, '2018-10-16 11:46:41', '19221', 'K.B.Prabha', 'PGM,Directors & VP', '145', 'Software', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass with distinction', 'Yes', 'Offshore'),
(10, 1, '2018-10-16 11:47:16', '19259', 'KALEESWARAN D', 'PM', '149', 'SOFTWARE', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 - Pass with merit', 'Yes', 'Offshore'),
(11, 1, '2018-10-16 11:47:28', '19265', 'G.Kavitha', 'PL', '146', 'KGiSL GSS Bullfinch', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass with distinction', 'Yes', 'Offshore'),
(12, 1, '2018-10-16 11:49:41', '19284', 'sathish kanna', 'Sr.ASSOCIATE', '141', 'ARM', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(13, 1, '2018-10-16 11:53:30', '16964', 'Yukthika LakshmiPathy', 'Sr.ASSOCIATE', '155', 'GSS', '05:00 pm â€“ 07:00 pm', 'Monday / Wednesday', 'B1 â€“ Pass with Merit', 'B2', 'No', 'Offshore'),
(14, 1, '2018-10-16 11:54:59', '20044', 'Prabhu', 'ASSOCIATE', '122', 'IAS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(15, 1, '2018-10-16 11:59:56', '19385', 'Muralidharan D', 'Sr.ASSOCIATE', '146', 'HMS', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B2', 'No', 'Onsite'),
(16, 1, '2018-10-16 12:08:35', '14200', 'JAYARAJ MOHAN J', 'PGM,Directors & VP', '145', 'IAS', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B2', 'Yes', 'Offshore'),
(17, 1, '2018-10-16 12:09:01', '19245', 'THIYAGARAJAN.S', 'PL', '144', 'DOLPHIN', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 - Pass with merit', 'Yes', 'Offshore'),
(18, 1, '2018-10-16 12:12:25', '19245', 'THIYAGARAJAN.S', 'PL', '144', 'DOLPHIN', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(19, 1, '2018-10-16 12:19:32', '18830', 'Brightymartina.M', 'ASSOCIATE', '134', 'Software Development', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(20, 1, '2018-10-16 12:20:06', '18194', 'Darani K', 'ASSOCIATE', '137', 'Software Development', '10:00 am â€“ 12:00 pm', 'Tuesday / Thursday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(21, 1, '2018-10-16 12:21:08', '20044', 'Prabhu', 'ASSOCIATE', '122', 'IAS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'A2', 'B2', 'Yes', 'Offshore'),
(22, 1, '2018-10-16 12:56:55', '19442', 'SANDHIYA C', 'ASSOCIATE', '130', 'HFF', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(23, 1, '2018-10-16 13:00:19', '19217', 'KRISHNAVENI.M', 'PGM,Directors & VP', '141', 'SOFTWARE', '09.00 am - 11.00 am', 'Friday / Saturday', 'B1 â€“ Pass', 'B1 â€“ Pass with distinction', 'Yes', 'Offshore'),
(24, 1, '2018-10-16 14:22:37', '11136', 'Chithra', 'PL', '136', 'Software - GSS (BSIB )', '05:00 pm â€“ 07:00 pm', 'Monday / Wednesday', 'A2', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(25, 1, '2018-10-17 03:31:54', '15265', 'T.SENGOTTUVELU', 'PL', '142', 'IAS', '05:00 pm â€“ 07:00 pm', 'Monday / Wednesday', 'B1 â€“ Pass', 'B2', 'Yes', 'Offshore'),
(26, 1, '2018-10-17 03:54:37', '19202', 'vaishnavi.u', 'ASSOCIATE', '70', 'GSS', '01:00 pm â€“ 03:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass', 'Yes', 'Offshore'),
(27, 1, '2018-10-17 04:26:03', '19473', 'Uma Maheswari.S', 'ASSOCIATE', '147', 'GSS/SHAREPOINT (741', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 - Pass with merit', 'No', 'Offshore'),
(28, 1, '2018-10-17 05:34:04', '19218', 'SIVARAJ S', 'PGM,Directors & VP', '136', 'HMS', '05:00 pm â€“ 07:00 pm', 'Monday / Wednesday', 'A2', 'B1 â€“ Pass with distinction', 'Yes', 'Offshore'),
(29, 1, '2018-10-17 05:46:42', '19219', 'Malathy K', 'PGM,Directors & VP', '149', 'Nsource', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'B1 â€“ Pass', 'B1 â€“ Pass with distinction', 'Yes', 'Offshore'),
(30, 1, '2018-10-17 06:26:45', '18439', 'Yasodha M', 'ASSOCIATE', '73', 'POOL', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'B1 â€“ Pass', 'B2', 'Yes', 'Offshore');

-- --------------------------------------------------------

--
-- Table structure for table `noncer`
--

CREATE TABLE `noncer` (
  `id` int(11) NOT NULL,
  `status` varchar(150) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `empid` varchar(150) NOT NULL,
  `empname` varchar(150) NOT NULL,
  `dept` varchar(150) NOT NULL,
  `tratime` varchar(150) NOT NULL,
  `batch` varchar(150) NOT NULL,
  `epiccate` varchar(150) NOT NULL,
  `predig` varchar(150) NOT NULL,
  `currentlocation` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `noncer`
--

INSERT INTO `noncer` (`id`, `status`, `created_at`, `empid`, `empname`, `dept`, `tratime`, `batch`, `epiccate`, `predig`, `currentlocation`) VALUES
(1, '1', '2018-10-16 11:34:11', '18725', 'Rajan G', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(2, '1', '2018-10-16 11:35:25', '21033', 'Haricharan Balakrishnan', 'Human Resources', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '22/10/18', 'Offshore'),
(3, '1', '2018-10-16 11:35:46', '14211', 'BOOPATHI.S.M', 'RHB', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(4, '1', '2018-10-16 11:35:59', '17153', 'ABRAHAM RAJESH A', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '22/10/18', 'Offshore'),
(5, '1', '2018-10-16 11:36:06', '17423', 'Raghupathy K', 'IAS-SAP', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(6, '1', '2018-10-16 11:37:39', '17694', 'HARIPRIYA S', 'RHB-GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(7, '1', '2018-10-16 11:37:57', '16327', 'Nagarajan K A', 'AXA', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(8, '1', '2018-10-16 11:38:07', '19322', 'VINOTH KUMAR K', 'DOLPHIN', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(9, '1', '2018-10-16 11:38:09', '20883', 'Vighashini R', 'GSS - Admin', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(10, '1', '2018-10-16 11:38:24', '19322', 'VINOTH KUMAR K', 'DOLPHIN', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(11, '1', '2018-10-16 11:40:28', '18731', 'Boopathyraj T', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(12, '1', '2018-10-16 11:40:34', '19275', 'Prabu Kumar S', 'GSS - Admin', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(13, '1', '2018-10-16 11:40:34', '19401', 'Suresh Kanna.S', 'KGISL-GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(14, '1', '2018-10-16 11:40:35', '20374', 'MUTHUGANESH', 'RELEASE MANAGEMENT TEAM', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(15, '1', '2018-10-16 11:41:52', '21428', 'ANAND KUMAR GANESH MUTHIAH', 'SOFTWARE DEVELOPMENT', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(16, '1', '2018-10-16 11:43:43', '18342', 'Subbulakshmi S', 'AXA AFFIN', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(17, '1', '2018-10-16 11:43:45', '19369', 'ALEXANDER X', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(18, '1', '2018-10-16 11:43:56', '19312', 'ANBARASU K', 'KGISL-GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(19, '1', '2018-10-16 11:44:22', '21187', 'Seshadri V', 'Presales', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(20, '1', '2018-10-16 11:44:30', '19396', 'Gunavadhi A S', 'IMS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '23/10/18', 'Offshore'),
(21, '1', '2018-10-16 11:46:14', '18722', 'sangeetha.s', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(22, '1', '2018-10-16 11:46:39', '17842', 'Prabhu G', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(23, '1', '2018-10-16 11:46:46', '19268', 'Mahitha.Gandhi', 'ARM', '01:00 pm â€“ 03:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(24, '1', '2018-10-16 11:47:30', '17694', 'HARIPRIYA S', 'RHB-GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '23/10/18', 'Offshore'),
(25, '1', '2018-10-16 11:47:48', '18730', 'Tamilarsan V', 'AXAAFFIN', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '22/10/18', 'Offshore'),
(26, '1', '2018-10-16 11:49:08', '16899', 'Saranyan Umapathy', 'NSOURCE', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '22/10/18', 'Offshore'),
(27, '1', '2018-10-16 11:50:45', '20046', 'Pradeep T', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(28, '1', '2018-10-16 11:51:29', '19374', 'VIJAYA BASKAR V', 'IMS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '23/10/18', 'Offshore'),
(29, '1', '2018-10-16 11:51:35', '19232', 'BALU P', 'HEALTH FIRST FINANCIAL (646)', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(30, '1', '2018-10-16 11:53:07', '19292', 'Ramesh C', 'ICT', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(31, '1', '2018-10-16 11:53:39', '19356', 'Rajasekar.N', 'ICT', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(32, '1', '2018-10-16 11:53:53', '16056', 'KARTHIKEYAN S', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(33, '1', '2018-10-16 11:54:02', '19374', 'VIJAYA BASKAR V', 'IMS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '23/10/18', 'Offshore'),
(34, '1', '2018-10-16 11:54:22', '19257', 'Manojkumar.TV', 'Dolphin', '10.00 am - 12.00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(35, '1', '2018-10-16 11:54:33', '19274', 'Pratheep Manikandan', 'ICT', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(36, '1', '2018-10-16 11:54:45', '16056', 'KARTHIKEYAN S', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(37, '1', '2018-10-16 11:55:18', '19256', ' sam manickaraj R', 'Dolphin', '10.00 am - 12.00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(38, '1', '2018-10-16 11:55:27', '21426', 'Maheshwaran B', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(39, '1', '2018-10-16 11:55:29', '21297', 'Sakshi Gupta', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '23/10/18', 'Offshore'),
(40, '1', '2018-10-16 11:56:08', '17768', 'K Saranesh Kumar', 'IAS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(41, '1', '2018-10-16 11:57:13', '21422', 'BALAMURUGANNITHIN R', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(42, '1', '2018-10-16 11:57:41', '21423', 'KISHOR R', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(43, '1', '2018-10-16 11:57:42', '19224', 'Rajkumar M', 'DolphinFX', '10.00 am - 12.00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(44, '1', '2018-10-16 11:57:53', '19269', 'sathishkumar s', 'Dolphin', '10.00 am - 12.00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(45, '1', '2018-10-16 11:58:24', '21283', 'Aiswarya Shanmugasundaram', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '23/10/18', 'Offshore'),
(46, '1', '2018-10-16 11:58:57', '21283', 'Aiswarya Shanmugasundaram', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '23/10/18', 'Offshore'),
(47, '1', '2018-10-16 11:59:16', '21359', 'CHANDIRAN S', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(48, '1', '2018-10-16 11:59:26', '21424', 'RAGAVI M', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(49, '1', '2018-10-16 12:00:02', '21359', 'CHANDIRAN S', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(50, '1', '2018-10-16 12:00:03', '21284', 'Aruna Thiyagarajan', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(51, '1', '2018-10-16 12:00:38', '21284', 'Aruna Thiyagarajan', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(52, '1', '2018-10-16 12:01:41', '16161', 'Madhu.D', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(53, '1', '2018-10-16 12:02:41', '19303', 'DHANAKUMAR.M', 'HEALTH FIRST FINANCIAL (646)', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(54, '1', '2018-10-16 12:05:14', '11689', 'SUDHAGAR M', 'KGISL-GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '22/10/18', 'Offshore'),
(55, '1', '2018-10-16 12:05:44', '20884', 'BALAMURALI KRISHNAN K', 'Dolphin', '11:00 am â€“ 01:00 pm', 'Saturday / Sunday', 'Ideal', '22/10/18', 'Offshore'),
(56, '1', '2018-10-16 12:06:34', '11689', 'SUDHAGAR M', 'KGISL-GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '22/10/18', 'Offshore'),
(57, '1', '2018-10-16 12:06:51', '20807', 'Elakkia', 'Gss', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '23/10/18', 'Offshore'),
(58, '1', '2018-10-16 12:07:05', '20686', 'Balamurugan.C', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '23/10/18', 'Offshore'),
(59, '1', '2018-10-16 12:07:05', '17372', 'Priyadarsini Balraj', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Excellent', '23/10/18', 'Offshore'),
(60, '1', '2018-10-16 12:07:11', '11521', 'Charles Prem F', 'ICT', '11:00 am â€“ 01:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(61, '1', '2018-10-16 12:07:18', '18141', 'RAMESH KUMAR.D', 'Doors', '10.00 am - 12.00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(62, '1', '2018-10-16 12:07:47', '19250', 'Vigneshkumar.AK', 'ICT', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(63, '1', '2018-10-16 12:08:04', '20807', 'Elakkia', 'Gss', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '23/10/18', 'Offshore'),
(64, '1', '2018-10-16 12:11:11', '19453', 'VINOTH.S', 'DOLPHIN', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Onsite'),
(65, '1', '2018-10-16 12:12:19', '21288', 'KARNA SAKTHIVEL', 'gss', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(66, '1', '2018-10-16 12:12:30', '21289', 'Karthic Natarajan', 'GSS', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(67, '1', '2018-10-16 12:13:53', '19296', 'TamilAarashan P', 'Software Development', '10.00 am - 12.00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(68, '1', '2018-10-16 12:13:54', '20523', 'JITHIN P K', 'GFS`', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(69, '1', '2018-10-16 12:13:59', '21287', 'parkavi.D', 'GSS', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(70, '1', '2018-10-16 12:14:12', '19466', 'Maheswari C', 'Software Development', '10.00 am - 12.00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(71, '1', '2018-10-16 12:14:15', '20523', 'JITHIN P K', 'GFS`', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(72, '1', '2018-10-16 12:14:20', '18064', 'Rajganesh.P', 'AXA', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(73, '1', '2018-10-16 12:15:27', '19351', 'Abuthahir', 'RHB Insuracne', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(74, '1', '2018-10-16 12:16:15', '20523', 'JITHIN P K', 'GFS', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(75, '1', '2018-10-16 12:16:45', '19479', 'R Muruganandhan', 'Dolphin', '01:00 pm â€“ 03:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(76, '1', '2018-10-16 12:17:12', '21308', 'Megharaj Yadravi', 'RPA', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(77, '1', '2018-10-16 12:19:51', '21303', 'Lahari s p', 'GSS', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(78, '1', '2018-10-16 12:20:08', '14195', 'BALASUBRAMANIAM.S', 'SOFTWARE DEVELOPMENT - HMS GSS', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Onsite'),
(79, '1', '2018-10-16 12:20:48', '21290', 'Raghul Gowtham Prabavathi Jayakumar', 'GSS', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(80, '1', '2018-10-16 12:30:08', '17588', 'Murukesh J', 'GSS', '11:00 am â€“ 01:00 pm', 'Tuesday / Thursday', 'Excellent', '22/10/18', 'Offshore'),
(81, '1', '2018-10-16 12:30:16', '17691', 'Nandhini.P', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '23/10/18', 'Offshore'),
(82, '1', '2018-10-16 12:31:01', '17691', 'Nandhini.P', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '23/10/18', 'Offshore'),
(83, '1', '2018-10-16 12:36:22', '18100', 'C Sanjay', 'Bullfinch', '05:00 pm â€“ 07:00 pm', 'Saturday / Sunday', 'Proficient', '22/10/18', 'Onsite'),
(84, '1', '2018-10-16 12:41:46', '20340', 'Raymond Justine Chen', 'Bullfinch', '05:00 pm â€“ 07:00 pm', 'Saturday / Sunday', 'Proficient', '22/10/18', 'Onsite'),
(85, '1', '2018-10-16 12:42:41', '18197', 'MAHENDRAN R', 'INFRA', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(86, '1', '2018-10-16 12:47:05', '17424', 'Navin.C', 'Software Development', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(87, '1', '2018-10-16 12:50:04', '21140', 'VENKATRAMAN', 'Dolphin', '01:00 pm â€“ 03:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(88, '1', '2018-10-16 12:50:45', '21140', 'VENKATRAMAN', 'SOFTWARE DEVELOPMENT', '01:00 pm â€“ 03:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(89, '1', '2018-10-16 12:57:11', '20045', 'ArunKumar.M', 'IAS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(90, '1', '2018-10-16 13:18:36', '19444', 'Ramachandran G', 'KYC', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(91, '1', '2018-10-16 13:21:09', '19413', 'SATHISHKUMAR DN', 'RELEASE MANAGEMENT TEAM', '11:00 am â€“ 01:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(92, '1', '2018-10-16 13:21:19', '18858', 'vijayabaskar.p', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(93, '1', '2018-10-16 13:22:49', '19454', 'SATHISHKUMAR M', 'RELEASE MANAGEMENT TEAM', '11:00 am â€“ 01:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(94, '1', '2018-10-16 13:24:07', '20055', 'RAJKUMAR', 'RELEASE MANAGEMENT TEAM', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(95, '1', '2018-10-16 13:34:16', '20673', 'Suryapathi S', 'Software Development', '10.00 am - 12.00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(96, '1', '2018-10-16 14:21:48', '19366', 'Silambarasan', 'ARM', '10.00 am - 12.00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(97, '1', '2018-10-16 15:03:32', '11163', 'Geetha Narayanaswamy', 'Software', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '23/10/18', 'Offshore'),
(98, '1', '2018-10-17 03:27:01', '13563', 'B.Sardhar', 'Software (GSS)', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(99, '1', '2018-10-17 03:29:02', '21285', 'INDHU S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(100, '1', '2018-10-17 03:29:54', '21285', 'INDHU S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(101, '1', '2018-10-17 03:29:54', '21285', 'INDHU S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(102, '1', '2018-10-17 03:30:10', '21280', 'Poorna Chandran Shanmugam', 'Gss', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(103, '1', '2018-10-17 03:31:04', '21310', 'Pavithra S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(104, '1', '2018-10-17 03:35:25', '21295', 'Dhiraj Mohan', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(105, '1', '2018-10-17 03:35:30', '21286', 'Nishanthi Rangarajan', 'GSS', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Excellent', '22/10/18', 'Offshore'),
(106, '1', '2018-10-17 03:36:39', '21439', 'Akila T', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '23/10/18', 'Offshore'),
(107, '1', '2018-10-17 03:39:11', '17811', 'Parthasarathe Palanisamy', 'KGISL - GSS', '05:00 pm â€“ 07:00 pm', 'Friday / Saturday', 'Excellent', '22/10/18', 'Offshore'),
(108, '1', '2018-10-17 03:40:19', '21425', 'Swetha.S', 'Trainee', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(109, '1', '2018-10-17 03:44:53', 'training', 'DIVYA P', 'Trainee', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(110, '1', '2018-10-17 03:45:39', 'training', 'DIVYA P', 'Trainee', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(111, '1', '2018-10-17 03:46:24', 'training', 'JANANI G', 'Trainee', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(112, '1', '2018-10-17 03:47:53', 'training', 'SHANMUGAM P', 'Trainee', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(113, '1', '2018-10-17 03:56:26', '20522', 'Gunavathi.S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '22/10/18', 'Offshore'),
(114, '1', '2018-10-17 03:57:43', '21292', 'Dulari N Bhatt', 'GSS', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Excellent', '22/10/18', 'Offshore'),
(115, '1', '2018-10-17 04:01:23', '15663', 'PARTHIBAN.D', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '22/10/18', 'Offshore'),
(116, '1', '2018-10-17 04:05:02', '14212', 'SABARIMANI S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(117, '1', '2018-10-17 04:05:09', 'TRAINEE', 'SUKUMAR  .M', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(118, '1', '2018-10-17 04:06:08', 'TRAINEE', 'SHANMUGHAPRIYAN S', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(119, '1', '2018-10-17 04:06:56', 'TRAINEE', 'MANOJKUMAR  P', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(120, '1', '2018-10-17 04:08:20', 'TRAINEE', 'JEGADESH B', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(121, '1', '2018-10-17 04:08:48', 'TRAINEE', 'ARAVINTH M D', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(122, '1', '2018-10-17 04:09:13', '14215', 'Surendhar M', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(123, '1', '2018-10-17 04:10:35', '14218', 'SANDAANA KRISHNAN I', 'GSS', '9.00 am - 11.00 am', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(124, '1', '2018-10-17 04:22:55', '21298', 'Kamalesh Sivakumar', 'Corp comm', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(125, '1', '2018-10-17 04:40:07', '20738', 'Dominic Titus', 'GSS/Bullfinch', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Ideal', '23/10/18', 'Offshore'),
(126, '1', '2018-10-17 04:48:17', '20671', 'Shanthini Chinnadurai', 'HFF', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(127, '1', '2018-10-17 05:05:04', '21352', 'Swathiga Jayachandran', 'Ntrust', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Capable', '22/10/18', 'Offshore'),
(128, '1', '2018-10-17 05:06:19', '21419', 'Siva Kumar Muthu Samy', 'Ntrust', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Capable', '22/10/18', 'Offshore'),
(129, '1', '2018-10-17 05:07:22', '21363', 'ArunKumar Ravichandran', 'GSS', '05:00 pm â€“ 07:00 pm', 'Tuesday / Thursday', 'Capable', '22/10/18', 'Offshore'),
(130, '1', '2018-10-17 05:32:48', '18853', 'SUBITHA M', 'SOFTWARE DEVELOPMENT', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(131, '1', '2018-10-17 05:32:50', '21136', 'Arul Guanasekar J', 'GSS', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(132, '1', '2018-10-17 05:33:11', '19267', 'Dhanapal Subramaniam', 'Dolphin Fx', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(133, '1', '2018-10-17 05:33:18', '21206', 'S.Sivasubramaniam', 'DBA', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(134, '1', '2018-10-17 05:34:06', '18853', 'SUBITHA M', 'SOFTWARE DEVELOPMENT', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '22/10/18', 'Offshore'),
(135, '1', '2018-10-17 05:34:22', '21282', 'Ganesh Manickam', 'Admin', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '22/10/18', 'Offshore'),
(136, '1', '2018-10-17 05:35:19', '21194', 'Ganesan.M', 'DBA', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Proficient', '23/10/18', 'Offshore'),
(137, '1', '2018-10-17 05:35:36', '19234', 'Rajaguru A', 'Dolphin Fx', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Capable', '22/10/18', 'Offshore'),
(138, '1', '2018-10-17 05:36:25', '18850', 'Santhosh Kumar.A', 'DolphinFX', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(139, '1', '2018-10-17 05:36:26', '19277', 'SRIRAM M I', 'HMS', '05:00 pm â€“ 07:00 pm', 'Monday / Wednesday', 'Proficient', '23/10/18', 'Offshore'),
(140, '1', '2018-10-17 05:49:08', '21299', 'Suresh Krishnamoorthi', 'GSS', '11:00 am â€“ 01:00 pm', 'Monday / Wednesday', 'Excellent', '22/10/18', 'Onsite'),
(141, '1', '2018-10-17 05:49:36', '21299', 'Suresh Krishnamoorthi', 'GSS', '11:00 am â€“ 01:00 pm', 'Monday / Wednesday', 'Excellent', '22/10/18', 'Onsite'),
(142, '1', '2018-10-17 05:50:51', '21299', 'Suresh Krishnamoorthi', 'GSS', '11:00 am â€“ 01:00 pm', 'Monday / Wednesday', 'Excellent', '22/10/18', 'Onsite'),
(143, '1', '2018-10-17 05:52:02', '21299', 'Suresh Krishnamoorthi', 'GSS', '11:00 am â€“ 01:00 pm', 'Monday / Wednesday', 'Excellent', '22/10/18', 'Onsite'),
(144, '1', '2018-10-17 05:55:31', '18851', 'Saritha Rajamanickam', 'SOFTWARE DEVELOPMENT', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Capable', '23/10/18', 'Offshore'),
(145, '1', '2018-10-17 06:20:35', '21364', 'GOKILAVANI CHANDRASEKARAN', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '23/10/18', 'Offshore'),
(146, '1', '2018-10-17 06:21:48', '19235', 'SANKARAN S', 'DOLPHIN FX', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(147, '1', '2018-10-17 06:22:12', '21301', 'Subashini U', 'GSS', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', 'Proficient', '23/10/18', 'Offshore'),
(148, '1', '2018-10-17 06:22:43', '19242', 'BARANEETHARAN R', 'TECH TEAM', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Ideal', '23/10/18', 'Offshore'),
(149, '1', '2018-10-17 06:24:09', '19655', 'gokul', 'gss', '9.00 am - 11.00 am', 'Monday / Wednesday', 'Non Mandatory', 'Non Mandatory', 'Onsite'),
(150, '1', '2018-10-17 06:31:53', '15866', 'MANIKANDAN', 'RHB', '10.00 am - 12.00 pm', 'Tuesday / Thursday', 'Capable', '', 'Offshore'),
(151, '1', '2018-10-17 06:33:54', '110011', 'aaa', 'aaa', '03:00 pm â€“ 05:00 pm', 'Monday / Wednesday', '', '23/10/18', 'Offshore'),
(152, '1', '2018-10-17 06:39:19', '11841', 'Priyadharsini.R', 'RHB', '03:00 pm â€“ 05:00 pm', 'Tuesday / Thursday', 'Excellent', '', 'Offshore');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `certificate`
--
ALTER TABLE `certificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noncer`
--
ALTER TABLE `noncer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `certificate`
--
ALTER TABLE `certificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `noncer`
--
ALTER TABLE `noncer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
