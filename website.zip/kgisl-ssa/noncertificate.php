<?php
include('config.php');
$uploadOk = 0;
if(isset($_POST['submit'])) {
	$uploadOk = 1;
	$name1 = $_POST['name'];
	$name2 = $_POST['department'];
	$name3 = $_POST['empid'];
	$name4 = $_POST['trainingtiming'];
	$name5 = $_POST['batch'];
	$name6 = $_POST['curbeclevel'];
	$name7 = $_POST['trabeclevel'];
	

	
$query=mysql_query("INSERT INTO `beccertification`(`name`, `department`,`empid`,`trainingtiming`,`batch`,`curbeclevel`,`trabeclevel`)
VALUE ('".$name1."','".$name2."','".$name3."','".$name4."','".$name5."','".$name6."','".$name7."')");


if($query)
{

	echo "
	
	
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>

<!-- Latest compiled JavaScript -->
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>

    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css' integrity='sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO' crossorigin='anonymous'>
     <script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>
	 <script>
	 window.location='BEC_Certification.php;
swal('Good job!', 'You clicked the button!', 'success')

</script>";
	
	
}
else{
	$uploadOk = 0;
	die("connection error:".mysql_error());
}
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>KGiSL</title>
	
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
	<link href="css/nivo-lightbox.css" rel="stylesheet" />
	<link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
	<link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
	<!-- template skin -->
	<link id="t-colors" href="color/default.css" rel="stylesheet">
    
    <!-- =======================================================
        Theme Name: Medicio
        Theme URL: https://bootstrapmade.com/medicio-free-bootstrap-theme/
        Author: BootstrapMade
        Author URL: https://bootstrapmade.com
    ======================================================= -->
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">

<div id="wrapper">
	
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="top-area">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-md-6">
					<p class="bold text-center">BEC CERTIFICATION – TRAINING REQUISITION FORM </p>
					</div>
					
				</div>
			</div>
		</div>
        <div class="container navigation">
		
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <img src="img/logo.png" alt="" width="150" height="40" />
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
			  <ul class="nav navbar-nav">
				<div class="buttonview">


<a class="btn btn-primary" href="certificated.php" role="button">BEC Upgradation Training</a>
<a class="btn btn-primary" href="noncertificate.php" role="button">New BEC Certification</a>
</div>
				
			  </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	

	<!-- Section: intro -->
    <section id="intro" class="intro">
		<div class="intro-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
					<div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
					<h2 class="h-ultra">BEC CERTIFICATION </h2>
					</div>
					<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.1s">
					<h4 class="h-light">NEXT EXAM DATE: 14th March 2019<br><br><span class="badge custom-badge red pull-left">*** Last date to submit this form ***</span> </h4>
					</div>
						<div class="well well-trans">
						<div class="wow fadeInRight" data-wow-delay="0.1s">

						<table class="table table-bordered">
  <thead>
    <tr>
      <center><h4><b>Expected Score</b></h4></center>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>JA/TR</td>
      <td>130</td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Associate</td>
      <td>140</td>

    </tr>
	 <tr>
      <th scope="row">3</th>
      <td>Sr.Associate</td>
      <td>143</td>

    </tr>
	 <tr>
      <th scope="row">4</th>
      <td>Prog Leader</td>
      <td>147</td>

    </tr>
	<tr>
      <th scope="row">5</th>
      <td>Prog Manager</td>
      <td>155</td>

    </tr><tr>
      <th scope="row">6</th>
      <td>Vp & Others</td>
      <td>160</td>

    </tr>
    
  </tbody>
</table>

						</div>
						</div>


					</div>
					<div class="col-lg-6">
						<div class="form-wrapper">
						<div class="wow fadeInRight" data-wow-duration="2s" data-wow-delay="0.2s">
						
							<div class="panel panel-skin">
							<div class="panel-heading">
									<h3 class="panel-title"><span class="fa fa-pencil-square-o"></span>BEC NON CERTIFIED CANDITATE <!--<small>(It's free!)</small>--></h3>
									</div>
									<div class="panel-body">
									    <div id="sendmessage">Your message has been sent. Thank you!</div>
                                        <div id="errormessage"></div>
                                   
    					                <form action="" method="post" role="form" class="contactForm lead">
    										<div class="row">
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Employee id</label>
    													<input type="text" name="first_name" id="first_name" class="form-control input-md" required data-error="Please upload your file"">
                                                        <div class="validation"></div>
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Employee Name</label>
    													<input type="text" name="last_name" id="last_name" class="form-control input-md" required data-error="Please upload your file"">
                                                        <div class="validation"></div>
    												</div>
    											</div>
    										</div>

    										<div class="row">
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Department</label>
														
														
														<input type="text" name="last_name" id="last_name" class="form-control input-md" required data-error="Please upload your file"">
    			
                                                        <div class="validation"></div>
														
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Training Timing</label>
    													<select class="custom-select form-control" input type="text"  name="trainingtiming" required data-error="Please upload your file" >
		<option selected></option>
  <option value="09.00 am - 11.00 am">09.00 am - 11.00 am</option>
  <option value="10:00 am – 12:00 pm">10.00 am - 12.00 pm</option>
  <option value="11:00 am – 01:00 pm">11:00 am – 01:00 pm</option>
  <option value="01:00 pm – 03:00 pm">01:00 pm – 03:00 pm</option>
  <option value="03:00 pm – 05:00 pm">03:00 pm – 05:00 pm</option>
  <option value="05:00 pm – 07:00 pm">05:00 pm – 07:00 pm</option>
</select>
                                                        <div class="validation"></div>
    												</div>
    											</div>
    										</div>
											
											<div class="row">
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Batch</label>
    													<select class="custom-select form-control" input type="text"  name="batch" required data-error="Please upload your file" >
  <option selected></option>
  <option value="Monday / Wednesday">Monday / Wednesday</option>
  <option value="Tuesday / Thursday">Tuesday / Thursday</option>
  <option value="Friday / Saturday">Friday / Saturday</option>
  <option value="Saturday / Sunday">Saturday / Sunday</option>
</select>
                                                        <div class="validation"></div>
    												</div>
    											</div>
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>EPIC Categorization</label>
    													<select class="custom-select form-control" input type="text"  name="batch" required data-error="Please upload your file" >
  <option selected></option>
  <option value="Excellent">Excellent</option>
  <option value="Proficient">Proficient</option>
  <option value="Ideal">Ideal</option>
  <option value="Capable">Capable</option>
</select>
                                                        <div class="validation"></div>
    												</div>
    											</div>
    										</div><div class="row">
    											<div class="col-xs-6 col-sm-6 col-md-6">
    												<div class="form-group">
    													<label>Preferred Digonostic Date</label>
    													 <select class="custom-select form-control" input type="text"  name="batch" required data-error="Please upload your file" >
  <option selected></option>
  <option value="17/10/18">17/10/18</option>
  <option value="22/10/18">22/10/18</option>
  <option value="23/10/18">23/10/18</option>
  <option value="24/10/18">24/10/18</option>
</select>
                                                        <div class="validation"></div>
    												</div>
    											</div>
    											
    										</div>
											
											
    										
    										<input type="submit" value="Submit" class="btn btn-skin btn-block btn-lg">
    										
    								
    									
    									</form>
								</div>
							</div>				
						
						</div>
						</div>
					</div>					
				</div>		
			</div>
		</div>		
    </section>
	
	<!-- /Section: intro -->

	<!-- Section: boxes -->
   
           

	
				
		<div class="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-6">
					<div class="wow fadeInLeft" data-wow-delay="0.1s">
					<div class="text-left">
					<p>&copy;Copyright - KGiSL. All rights reserved.</p>
					</div>
					</div>
				</div>
				
			</div>	
		</div>
		</div>
	</footer>

</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

	<!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>

</html>
